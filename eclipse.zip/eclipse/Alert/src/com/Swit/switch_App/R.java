package com.Swit.switch_App;

public class R {

	public static Object layout;
	public static Object id;

}
