/** Automatically generated file. DO NOT MODIFY */
package com.alert.alert;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}